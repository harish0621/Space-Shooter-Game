
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let keys = {};
let bullets = [];
let enemies = [];
let powerups = [];
let score = 0;
let lives = 3;
let wave = 1;
let playerSpeed = 5;
let bulletCooldown = 0;

const playerImg = new Image();
playerImg.src = 'assets/player.png';
const enemyImg = new Image();
enemyImg.src = 'assets/enemy.png';

const player = {
  x: canvas.width / 2 - 32,
  y: canvas.height - 70,
  width: 64,
  height: 64,
  draw() {
    ctx.drawImage(playerImg, this.x, this.y, this.width, this.height);
  }
};

document.addEventListener('keydown', e => keys[e.key] = true);
document.addEventListener('keyup', e => keys[e.key] = false);

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  player.draw();

  if (keys['ArrowLeft'] && player.x > 0) player.x -= playerSpeed;
  if (keys['ArrowRight'] && player.x < canvas.width - player.width) player.x += playerSpeed;

  if (keys[' '] && bulletCooldown <= 0) {
    bullets.push({ x: player.x + 24, y: player.y, width: 5, height: 10 });
    bulletCooldown = 20;
  }
  bulletCooldown--;

  bullets = bullets.filter(b => b.y > 0);
  bullets.forEach(b => {
    b.y -= 10;
    ctx.fillStyle = 'cyan';
    ctx.fillRect(b.x, b.y, b.width, b.height);
  });

  if (enemies.length === 0) {
    for (let i = 0; i < wave * 5; i++) {
      enemies.push({ x: Math.random() * 740, y: Math.random() * -300, width: 50, height: 50, speed: 2 + wave });
    }
  }

  enemies.forEach((e, i) => {
    e.y += e.speed;
    ctx.drawImage(enemyImg, e.x, e.y, e.width, e.height);
    if (collision(e, player)) {
      enemies.splice(i, 1);
      lives--;
    }
    bullets.forEach((b, j) => {
      if (collision(b, e)) {
        bullets.splice(j, 1);
        enemies.splice(i, 1);
        score += 100;
      }
    });
  });

  ctx.fillStyle = 'white';
  ctx.font = '20px Arial';
  ctx.fillText(`Score: ${score}`, 10, 20);
  ctx.fillText(`Lives: ${lives}`, 10, 45);
  ctx.fillText(`Wave: ${wave}`, 10, 70);

  if (lives <= 0) {
    ctx.fillStyle = 'red';
    ctx.font = '50px Arial';
    ctx.fillText('Game Over', 300, 300);
    return;
  }

  if (enemies.length === 0) wave++;

  requestAnimationFrame(update);
}

function collision(a, b) {
  return a.x < b.x + b.width &&
         a.x + a.width > b.x &&
         a.y < b.y + b.height &&
         a.y + a.height > b.y;
}

update();
